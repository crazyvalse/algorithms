export const utils = {
  trim() {},
  handle() {}
}

// module -> import/export
